//
//  operation.swift
//  calc
//
//  Created by Susana on 5/3/2025.
//  Copyright © 2025 UTS. All rights reserved.
//

// This is a swift file that store all the function about calculator. It can be extended in the future development

// This is an addition function, it will receive 2 integer numbers and return a result of addition
func add(num1:Int, num2:Int) -> Int {
    return num1 + num2
}

// This is an substractive function, it will receive 2 integer numbers and return a result of substraction
func substract(num1:Int, num2:Int) -> Int {
    return num1 - num2
}

// This is an multiplicative function, it will receive 2 integer numbers and return a result of multiplication
func multiply(num1:Int, num2:Int) -> Int {
    return num1 * num2
}

// This is an division function, it will receive 2 integer numbers and return a result of division
func divide(num1:Int, num2:Int) throws -> Int {
    // before division, it is important to make sure the divisor is not 0
    if(num2 == 0){
        throw errorType.divideByZero("Cannot devide a number by zero")
    }
    return num1 / num2
}

// This is an modulus function, it will receive 2 integer numbers and return a result of remainder
func mod(num1:Int, num2:Int) -> Int {
    return num1 % num2
}
