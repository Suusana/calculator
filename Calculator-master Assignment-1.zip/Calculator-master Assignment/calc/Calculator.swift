//
//  Calculator.swift
//  calc
//
//  Created by Jacktator on 31/3/20.
//  Copyright © 2020 UTS. All rights reserved.
//

import Foundation

class Calculator {
    // this is a veriable that accept the result of every calculation
    var currentResult = 0
    // define an array of input operators and numbers
    var operators:[String] = []
    var numbers:[Int] = []
    
    // We can calculate the result in this function
    func calculate(args: [String]) throws -> String {
        
//      traversal all the value in args
        for value in args {
            // store all the input numbers in array "numbers"
            if let number = Int(value){
                numbers.append(number)
            } else {
                // store all the input operators in array "operators"
                operators.append(value)
            }
        }
        
        // we firstly ignore "+" and "-" and start with "x" "/" and "%"
        var index = 0 // the current index
        // traversal the operators
        while index < operators.count {
            let firstNum = numbers[index]
            let secondNum = numbers[index+1]
            switch operators[index]{
            case "x":
                currentResult = multiply(num1:firstNum, num2:secondNum)
                // update the array "numbers", see the function "updateNumbers" below to know more details
                updateNumbers(index: index, value: currentResult)
                // after updated the array "numbers", we need to also update the array "operators" to ensure the consistency of index
                operators.remove(at: index)
            case "/":
                currentResult = try divide(num1:firstNum, num2:secondNum)
                updateNumbers(index: index, value: currentResult)
                operators.remove(at: index)
            case "%":
                currentResult = mod(num1:firstNum, num2:secondNum)
                updateNumbers(index: index, value: currentResult)
                operators.remove(at: index)
            default:
                // if we didnt find "x" or "/" or "%", then we can go to the next index (next operator)
                index += 1
            }
        }
        
        // after completing "x", "/", and "%", we can start dealing with "+" and "-"
        for symbol in operators {
            if symbol == "+"{
                // there is no "x", "/"or "%" left, so we can calculate from left to right
                currentResult = add(num1: numbers[0], num2: numbers[1])
            } else {
                currentResult = substract(num1: numbers[0], num2: numbers[1])
            }
            // we just update index 0 and delete index 1, then repeat these steps
            updateNumbers(index: 0, value: currentResult)
        }
        
        // print the result
        let dummyResult = currentResult
        let result = String(dummyResult)
        return(result)
    }
    
    // This is a function that will update the array "numbers" which was created in line 16
    // parameters: index : the index of the array "numbers" which needed to be updated
    //             value: the result (+,-,x,/,%) of numbers[index] and numbers[index+1]
    func updateNumbers(index:Int, value:Int) {
        // we replace the array's index position number with the result value
        // eg : numbers: [1,2,3] operators: [+,+]
        // we need to update the 0-index with the result of 1+2, then it will be numbers:[3,2,3]
        numbers[index] = value
        //after update the value ,then we can delete the next number[3,2,3] -> [3,3]
        numbers.remove(at: index+1)
    }
}
