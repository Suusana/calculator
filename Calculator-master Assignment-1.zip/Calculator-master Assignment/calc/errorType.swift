//
//  errorType.swift
//  calc
//
//  Created by Susana on 5/3/2025.
//  Copyright © 2025 UTS. All rights reserved.
//

// This is a swift file that store all the invalid input type. It can be extended in the future development
enum errorType : Error{
    // error when there is invalid input
    case invalidInput(String)
    // error when a divisor is 0
    case divideByZero(String)
}
