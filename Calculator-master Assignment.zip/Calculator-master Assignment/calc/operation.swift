//
//  operation.swift
//  calc
//
//  Created by Susana on 5/3/2025.
//  Copyright © 2025 UTS. All rights reserved.
//

// This is a swift file that store all the function about calculator. It can be extended in the future development

// This is an addition function, it will receive an integer array with 2 elements and return a result of addition
func add(numbers:[Int]) -> Int {
    return numbers[0] + numbers[1]
}

// This is an substractive function, it will receive an integer array with 2 elements and return a result of substraction
func substract(numbers:[Int]) -> Int {
    return numbers[0] - numbers[1]
}

// This is an multiplicative function, it will receive an integer array with 2 elements and return a result of multiplication
func multiply(numbers:[Int]) -> Int {
    return numbers[0] * numbers[1]
}

// This is an division function, it will receive an integer array with 2 elements and return a result of division
func divide(numbers:[Int]) throws -> Int {
    // before division, it is important to make sure the divisor is not 0
    if(numbers[1]==0){
        throw errorType.divideByZero("Cannot devide a number by zero")
    }
    return numbers[0] / numbers[1]
}

// This is an modulus function, it will receive an integer array with 2 elements and return a result of remainder
func mod(numbers:[Int]) -> Int {
    return numbers[0] % numbers[1]
}
