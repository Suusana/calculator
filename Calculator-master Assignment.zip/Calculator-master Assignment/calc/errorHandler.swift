//
//  errorHandler.swift
//  calc
//
//  Created by Susana on 5/3/2025.
//  Copyright © 2025 UTS. All rights reserved.
//

// This is a function that will check whether the input value is valid or not
func checkValidity(args:[String]) throws {
    // define an Array of valid operators
    let validOperator = ["+","-","x","/","%"]

    // traversal all the values in the args
    for value in args {
        // check if the current value is an valid operator, if yes, then it pass. We can check the next value
        if validOperator.contains(value) {
            continue
        }
        
        // check if the current value can cenvert to integer, if no, then we throw an error showing that this input number is invalid
        if Int(value) == nil {
            throw errorType.invalidInput("Invalid input number, you can only enter integer number")
        }
    }
    
    // We consider one situation that user only enter one input and this input is not an operator (means it is a integer number)
    if args.count == 1 && !validOperator.contains(args[0]){
        // In this case, the calculator will print the number directly without error
        // eg: input ["88"] output: 88
        if let num = Int(args[0]){
            print(num)
        }
    }
    
    // another situation: check if the array has an odd number of inputs.
    // e.g: ["1","+","1"]: number of inputs is 3, ["8","-","6","+","3"]: number of inputs is 5.
    // If no, then we throw an error message showing that these input is invalid
    guard args.count > 1 && args.count % 2 == 1 else {
        throw errorType.invalidInput("Invalid number of inputs")
    }
    
    // we also should make sure that the input numbers are in even index while input operators are in odd index
    //eg:       ["1","+","1"]  ["8","-","6","+","3"]
    // index:     0   1   2      0   1   2   3   4
    for (index, value) in args.enumerated(){
        // even index
        if index % 2 == 0 && Int(value) == nil {
            throw errorType.invalidInput("Invalid input")
        } else if index % 2 == 1 && !validOperator.contains(value) {
            // odd index
            throw errorType.invalidInput("Invalid input")
        }
    }
}
